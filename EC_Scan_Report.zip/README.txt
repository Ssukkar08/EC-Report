
EC Scan App - Progress Bar Version (All ECs)

Focus: Main fields & approvals (ENG, MFG, QUALITY, PURCHASING, SALES, MARKETING)

What's new:
- Scan the TOP-LEVEL ECs folder and all subfolders (all years)
- ProgressBar + Cancel
- Timestamped output: Consolidated_EC_Summary_ALL_<YYYYMMDD_HHMMSS>.xlsx

How to use:
1) Open EC_Scan_Report.sln in Visual Studio 2022+
2) Restore NuGet packages: ClosedXML
3) Build & Run
4) Click Generate Report, select your top-level ECs folder (e.g., ECs (Engineering Changes))
5) Watch progress; click Cancel to stop
6) Report is saved in the chosen folder with timestamp

Notes:
- App reads the FIRST sheet of each .xlsx and looks for keys: EC#, Originator, Origination Date, Priority, Change Description
- Approvals captured from rows labeled: ENG, MFG, QUALITY, PURCHASING, SALES, MARKETING
- Skips temp/lock files that start with ~$ and .tmp
